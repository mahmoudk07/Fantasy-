﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJECT
{
    public partial class SUPPORTER : Form
    {
        Controller controllerObj = new Controller();
        public SUPPORTER()
        {
            InitializeComponent();
        }

        private void SUPPORTER_Load(object sender, EventArgs e)
        {

        }
    }
}
