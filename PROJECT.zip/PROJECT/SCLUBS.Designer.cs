﻿namespace PROJECT
{
    partial class SCLUBS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.AHLYPIC = new System.Windows.Forms.PictureBox();
            this.BAYERNPIC = new System.Windows.Forms.PictureBox();
            this.PARISPIC = new System.Windows.Forms.PictureBox();
            this.LIVERPIC = new System.Windows.Forms.PictureBox();
            this.BARCAPIC = new System.Windows.Forms.PictureBox();
            this.REALPIC = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.AHLYPIC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BAYERNPIC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PARISPIC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LIVERPIC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BARCAPIC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.REALPIC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(177, 286);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(182, 22);
            this.textBox1.TabIndex = 12;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(177, 326);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(182, 22);
            this.textBox2.TabIndex = 13;
            // 
            // textBox3
            // 
            this.textBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3.Location = new System.Drawing.Point(177, 372);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(182, 22);
            this.textBox3.TabIndex = 14;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(177, 414);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(182, 22);
            this.textBox4.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 372);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 20);
            this.label1.TabIndex = 16;
            this.label1.Text = "BUDGET";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 416);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 20);
            this.label2.TabIndex = 17;
            this.label2.Text = "CITY";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(8, 286);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 20);
            this.label3.TabIndex = 18;
            this.label3.Text = "CLUB NAME";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(8, 326);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 20);
            this.label4.TabIndex = 19;
            this.label4.Text = "FOUND_DATE";
            // 
            // AHLYPIC
            // 
            this.AHLYPIC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AHLYPIC.Image = global::PROJECT.Properties.Resources.WhatsApp_Image_2022_01_05_at_9_41_27_PM__2_;
            this.AHLYPIC.Location = new System.Drawing.Point(671, 28);
            this.AHLYPIC.Name = "AHLYPIC";
            this.AHLYPIC.Size = new System.Drawing.Size(100, 129);
            this.AHLYPIC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AHLYPIC.TabIndex = 11;
            this.AHLYPIC.TabStop = false;
            this.AHLYPIC.Click += new System.EventHandler(this.AHLYPIC_Click);
            // 
            // BAYERNPIC
            // 
            this.BAYERNPIC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BAYERNPIC.Image = global::PROJECT.Properties.Resources.WhatsApp_Image_2022_01_05_at_9_41_28_PM;
            this.BAYERNPIC.Location = new System.Drawing.Point(542, 28);
            this.BAYERNPIC.Name = "BAYERNPIC";
            this.BAYERNPIC.Size = new System.Drawing.Size(100, 129);
            this.BAYERNPIC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BAYERNPIC.TabIndex = 10;
            this.BAYERNPIC.TabStop = false;
            this.BAYERNPIC.Click += new System.EventHandler(this.BAYERNPIC_Click);
            // 
            // PARISPIC
            // 
            this.PARISPIC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PARISPIC.Image = global::PROJECT.Properties.Resources.WhatsApp_Image_2022_01_05_at_10_38_05_PM;
            this.PARISPIC.Location = new System.Drawing.Point(405, 28);
            this.PARISPIC.Name = "PARISPIC";
            this.PARISPIC.Size = new System.Drawing.Size(100, 129);
            this.PARISPIC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PARISPIC.TabIndex = 9;
            this.PARISPIC.TabStop = false;
            this.PARISPIC.Click += new System.EventHandler(this.PARISPIC_Click);
            // 
            // LIVERPIC
            // 
            this.LIVERPIC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LIVERPIC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LIVERPIC.Image = global::PROJECT.Properties.Resources.WhatsApp_Image_2022_01_05_at_9_41_28_PM__1_;
            this.LIVERPIC.Location = new System.Drawing.Point(273, 28);
            this.LIVERPIC.Name = "LIVERPIC";
            this.LIVERPIC.Size = new System.Drawing.Size(100, 129);
            this.LIVERPIC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LIVERPIC.TabIndex = 8;
            this.LIVERPIC.TabStop = false;
            this.LIVERPIC.Click += new System.EventHandler(this.LIVERPIC_Click);
            // 
            // BARCAPIC
            // 
            this.BARCAPIC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BARCAPIC.Image = global::PROJECT.Properties.Resources.WhatsApp_Image_2022_01_05_at_9_41_27_PM__3_;
            this.BARCAPIC.Location = new System.Drawing.Point(147, 28);
            this.BARCAPIC.Name = "BARCAPIC";
            this.BARCAPIC.Size = new System.Drawing.Size(104, 131);
            this.BARCAPIC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BARCAPIC.TabIndex = 7;
            this.BARCAPIC.TabStop = false;
            this.BARCAPIC.Click += new System.EventHandler(this.BARCAPIC_Click);
            // 
            // REALPIC
            // 
            this.REALPIC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.REALPIC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.REALPIC.Image = global::PROJECT.Properties.Resources.REAL;
            this.REALPIC.Location = new System.Drawing.Point(12, 32);
            this.REALPIC.Name = "REALPIC";
            this.REALPIC.Size = new System.Drawing.Size(104, 125);
            this.REALPIC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.REALPIC.TabIndex = 5;
            this.REALPIC.TabStop = false;
            this.REALPIC.Click += new System.EventHandler(this.REALPIC_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PROJECT.Properties.Resources.WhatsApp_Image_2022_01_05_at_10_42_57_PM;
            this.pictureBox1.Location = new System.Drawing.Point(0, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(799, 463);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(542, 288);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(240, 150);
            this.dataGridView1.TabIndex = 20;
            this.dataGridView1.Visible = false;
            // 
            // SCLUBS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.AHLYPIC);
            this.Controls.Add(this.BAYERNPIC);
            this.Controls.Add(this.PARISPIC);
            this.Controls.Add(this.LIVERPIC);
            this.Controls.Add(this.BARCAPIC);
            this.Controls.Add(this.REALPIC);
            this.Controls.Add(this.pictureBox1);
            this.Name = "SCLUBS";
            this.Text = "SCLUBS";
            this.Load += new System.EventHandler(this.SCLUBS_Load);
            ((System.ComponentModel.ISupportInitialize)(this.AHLYPIC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BAYERNPIC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PARISPIC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LIVERPIC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BARCAPIC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.REALPIC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox PARISPIC;
        private System.Windows.Forms.PictureBox LIVERPIC;
        private System.Windows.Forms.PictureBox BARCAPIC;
        private System.Windows.Forms.PictureBox REALPIC;
        private System.Windows.Forms.PictureBox BAYERNPIC;
        private System.Windows.Forms.PictureBox AHLYPIC;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}